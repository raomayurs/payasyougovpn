export const cognitoConfig =  {
    userPoolId: "",
    identityPoolId: "",
    clientId: "",
    region: ""
}
